#include <stdint.h>
#if defined(__aarch64__)
#include <arm_neon.h>

// -march=armv8.2-a+crypto+dotprod bilan kompilyatsiya qilinadi (CMakeLists.txt).
// Faqat CPU'da AES va DOTPROD borligi tekshirilgandan keyin chaqiriladi.
float burn_x(int reps) {
    const uint8x16_t k = vdupq_n_u8(0x5A);
    uint8x16_t s0 = vdupq_n_u8(1), s1 = vdupq_n_u8(2), s2 = vdupq_n_u8(3), s3 = vdupq_n_u8(4);
    const int8x16_t va = vdupq_n_s8(3), vb = vdupq_n_s8(5);
    int32x4_t d0 = vdupq_n_s32(0), d1 = vdupq_n_s32(1), d2 = vdupq_n_s32(2), d3 = vdupq_n_s32(3);
    for (int i = 0; i < reps; i++) {
        s0 = vaesmcq_u8(vaeseq_u8(s0, k)); s1 = vaesmcq_u8(vaeseq_u8(s1, k));
        s2 = vaesmcq_u8(vaeseq_u8(s2, k)); s3 = vaesmcq_u8(vaeseq_u8(s3, k));
        d0 = vdotq_s32(d0, va, vb); d1 = vdotq_s32(d1, va, vb);
        d2 = vdotq_s32(d2, va, vb); d3 = vdotq_s32(d3, va, vb);
    }
    int32x4_t d = vaddq_s32(vaddq_s32(d0, d1), vaddq_s32(d2, d3));
    uint8x16_t s = veorq_u8(veorq_u8(s0, s1), veorq_u8(s2, s3));
    return (float)vaddvq_s32(d) + (float)vgetq_lane_u8(s, 0);
}
#else
float burn_x(int) { return 0.0f; }
#endif
