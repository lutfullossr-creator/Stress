#include <jni.h>
#include <stdlib.h>
#include <stddef.h>
#if defined(__ARM_NEON) && defined(__aarch64__)
#include <arm_neon.h>
#define HAVE_NEON 1
#endif
#ifdef XTREME
#include <sys/auxv.h>
float burn_x(int reps);   // burnx.cpp: AES + int8 dot-product (armv8.2)
#endif

static const size_t N = 4u * 1024u * 1024u;   // 4M float = 16 MB (kesh sig'maydi -> RAM yuklanadi)
static thread_local float* g_buf = nullptr;

extern "C" JNIEXPORT jfloat JNICALL
Java_com_edi_stress_Native_burn(JNIEnv*, jclass, jint reps, jint stream) {
#ifdef HAVE_NEON
    const float32x4_t a = vdupq_n_f32(0.99991f);
    const float32x4_t c = vdupq_n_f32(0.00009f);
    float32x4_t x0 = vdupq_n_f32(0.10f), x1 = vdupq_n_f32(0.20f);
    float32x4_t x2 = vdupq_n_f32(0.30f), x3 = vdupq_n_f32(0.40f);
    float32x4_t x4 = vdupq_n_f32(0.50f), x5 = vdupq_n_f32(0.60f);
    float32x4_t x6 = vdupq_n_f32(0.70f), x7 = vdupq_n_f32(0.80f);
    uint64_t h0 = 1, h1 = 2, h2 = 3, h3 = 4;   // skalyar butun son zanjirlari: NEON bilan bir vaqtda boshqa konveyerlarni yuklaydi
    const uint64_t KM = 6364136223846793005ULL, KA = 1442695040888963407ULL;
    for (int i = 0; i < reps; i++) {          // 8 mustaqil FMA zanjiri: ikkala NEON konveyer to'liq band
        h0 = h0 * KM + KA; h1 = h1 * KM + KA; h2 = h2 * KM + KA; h3 = h3 * KM + KA;
        x0 = vfmaq_f32(c, x0, a); x1 = vfmaq_f32(c, x1, a);
        x2 = vfmaq_f32(c, x2, a); x3 = vfmaq_f32(c, x3, a);
        x4 = vfmaq_f32(c, x4, a); x5 = vfmaq_f32(c, x5, a);
        x6 = vfmaq_f32(c, x6, a); x7 = vfmaq_f32(c, x7, a);
    }
    float32x4_t s = vaddq_f32(vaddq_f32(vaddq_f32(x0, x1), vaddq_f32(x2, x3)),
                              vaddq_f32(vaddq_f32(x4, x5), vaddq_f32(x6, x7)));
    float r = vaddvq_f32(s) + (float)((h0 ^ h1 ^ h2 ^ h3) & 0xFFu);
#ifdef XTREME
    {
        static int g_x = -1;
        if (g_x < 0) {
            unsigned long hw = getauxval(AT_HWCAP);
            g_x = ((hw & (1UL << 3)) && (hw & (1UL << 20))) ? 1 : 0;   // AES va ASIMDDP bor-yo'qligini tekshiramiz
        }
        if (g_x) r += burn_x(reps / 2);
    }
#endif
    if (stream > 0) {
        if (!g_buf) {
            g_buf = (float*)malloc(N * sizeof(float));
            if (!g_buf) return r;
            for (size_t i = 0; i < N; i++) g_buf[i] = 1.0f;
        }
        for (int pass = 0; pass < stream; pass++)
        for (size_t i = 0; i + 16 <= N; i += 16) {
            float32x4_t v0 = vld1q_f32(g_buf + i);
            float32x4_t v1 = vld1q_f32(g_buf + i + 4);
            float32x4_t v2 = vld1q_f32(g_buf + i + 8);
            float32x4_t v3 = vld1q_f32(g_buf + i + 12);
            v0 = vfmaq_f32(c, v0, a); v1 = vfmaq_f32(c, v1, a);
            v2 = vfmaq_f32(c, v2, a); v3 = vfmaq_f32(c, v3, a);
            vst1q_f32(g_buf + i, v0); vst1q_f32(g_buf + i + 4, v1);
            vst1q_f32(g_buf + i + 8, v2); vst1q_f32(g_buf + i + 12, v3);
        }
        r += g_buf[N / 2];
    }
    return r;
#else
    float x = 0.5f;
    for (int i = 0; i < reps; i++) x = x * 0.99991f + 0.00009f;
    return x;
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_com_edi_stress_Native_tier(JNIEnv*, jclass) {
#ifdef XTREME
    unsigned long hw = getauxval(AT_HWCAP);
    return ((hw & (1UL << 3)) && (hw & (1UL << 20))) ? 2 : 1;
#else
    return 1;
#endif
}
