package com.edi.stress

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class ChartView(ctx: Context) : View(ctx) {
    var cpu: List<Float> = emptyList()
    var gpu: List<Float> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 5f; style = Paint.Style.STROKE }
    private val grid = Paint().apply { color = Color.parseColor("#2a3340"); strokeWidth = 2f }

    private fun line(c: Canvas, a: List<Float>, color: Int) {
        if (a.size < 2) return
        p.color = color
        val w = width.toFloat(); val h = height.toFloat()
        var px = 0f; var py = 0f
        a.forEachIndexed { i, v ->
            val x = i.toFloat() / (a.size - 1) * w
            val y = h - 6f - (v.coerceIn(0f, 110f) / 110f) * (h - 12f)
            if (i > 0) c.drawLine(px, py, x, y, p)
            px = x; py = y
        }
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#0c1015"))
        val y100 = height - 6f - (100f / 110f) * (height - 12f)
        c.drawLine(0f, y100, width.toFloat(), y100, grid)
        line(c, cpu, Color.parseColor("#ff5a36"))
        line(c, gpu, Color.parseColor("#5aa9ff"))
    }
}
