package com.edi.stress

object Native {
    val ok: Boolean = try {
        System.loadLibrary("burn")
        true
    } catch (e: Throwable) {
        false
    }

    @JvmStatic
    external fun burn(reps: Int, stream: Int): Float

    @JvmStatic
    external fun tier(): Int
}
