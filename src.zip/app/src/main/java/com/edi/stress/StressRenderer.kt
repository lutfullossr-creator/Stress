package com.edi.stress

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Haqiqiy GPU yuklama: shaderda erta chiqish yo'q, tasodifiy tekstura o'qish, additiv blending (overdraw kesilmaydi),
 * o'tishlar soni dastlabki 4 soniyada moslanadi va keyin qotiriladi (throttling aniq ko'rinsin).
 */
class StressRenderer : GLSurfaceView.Renderer {
    @Volatile var active = false
    @Volatile var frames = 0L
    @Volatile var work = 0.0            // jami bajarilgan: piksel x sikl x o'tish
    @Volatile var gpuName = ""
    @Volatile var error: String? = null
    @Volatile var frameMs = 0.0
    @Volatile var passesNow = 1
    @Volatile var pixels = 0
    @Volatile var busyMs = 0.0          // GPU band bo'lgan jami vaqt (ms)
    @Volatile var targetMs = 55.0
    @Volatile var duty = 100            // GPU band bo'lish ulushi, %

    private var prog = 0
    private var w = 1
    private var h = 1
    private var tLoc = 0
    private var rLoc = 0
    private var gLoc = 0
    private var texLoc = 0
    private var tex = 0
    private var passes = 1.0
    private var calibUntil = 0L
    private var wasActive = false

    private val verts = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
    }

    companion object { const val LOOP = 192 }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) error = "Shader xatosi: " + GLES20.glGetShaderInfoLog(s)
        return s
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        gpuName = (GLES20.glGetString(GLES20.GL_RENDERER) ?: "?") + " / " + (GLES20.glGetString(GLES20.GL_VENDOR) ?: "")
        val vs = "attribute vec2 p; void main(){ gl_Position = vec4(p,0.0,1.0); }"
        val fs = """
            precision highp float;
            uniform float t; uniform float gain; uniform vec2 r; uniform sampler2D tex;
            void main(){
                vec2 uv = gl_FragCoord.xy / r;
                vec4 z = vec4(uv * 2.0 - 1.0, uv.yx);
                vec4 a = vec4(0.0);
                vec3 c = vec3(0.0);
                for(int i = 0; i < $LOOP; i++){
                    z = sin(z.yzwx * 1.7 + t) + cos(z.wxyz * 2.3 - t) * 0.9;
                    z = z * z.zwxy + z.yzwx * 0.35;
                    a += exp2(z * 0.4) * 0.01 + atan(z, z.yzwx) * 0.01;
                    a += sin(length(z) * 3.0 + vec4(float(i) * 0.1, 1.0, 2.0, 3.0)) + inversesqrt(abs(z) + 1.0);
                    if (mod(float(i), 2.0) < 0.5) {
                        c += texture2D(tex, fract(z.xy * 0.31 + uv)).rgb + texture2D(tex, fract(z.zw * 0.27 - uv)).rgb;
                    }
                }
                vec3 col = vec3(fract(a.x * 0.01), fract(c.g * 0.05), fract(c.b * 0.05 + a.y * 0.01));
                gl_FragColor = vec4(col * gain, 1.0);
            }
        """.trimIndent()
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(prog, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0 && error == null) error = "Link xatosi: " + GLES20.glGetProgramInfoLog(prog)
        tLoc = GLES20.glGetUniformLocation(prog, "t")
        rLoc = GLES20.glGetUniformLocation(prog, "r")
        gLoc = GLES20.glGetUniformLocation(prog, "gain")
        texLoc = GLES20.glGetUniformLocation(prog, "tex")

        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0); tex = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        val arr = ByteArray(2048 * 2048 * 4); java.util.Random(1).nextBytes(arr)
        val buf = ByteBuffer.allocateDirect(arr.size).order(ByteOrder.nativeOrder()); buf.put(arr); buf.position(0)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 2048, 2048, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)

        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width; h = height; pixels = width * height
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (!active || prog == 0 || error != null) {
            wasActive = false
            GLES20.glClearColor(0.05f, 0.07f, 0.1f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }
        if (!wasActive) {
            wasActive = true; passes = 1.0
            calibUntil = System.nanoTime() + 4_000_000_000L
        }
        val t0 = System.nanoTime()
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        val pl = GLES20.glGetAttribLocation(prog, "p")
        GLES20.glEnableVertexAttribArray(pl)
        GLES20.glVertexAttribPointer(pl, 2, GLES20.GL_FLOAT, false, 0, verts)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(texLoc, 0)
        GLES20.glUniform2f(rLoc, w.toFloat(), h.toFloat())
        val n = passes.roundToInt().coerceIn(1, 128)
        GLES20.glUniform1f(gLoc, 1f / n)
        for (k in 0 until n) {
            GLES20.glUniform1f(tLoc, (frames % 1000) * 0.05f + k * 0.37f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }
        GLES20.glFinish()
        val ms = (System.nanoTime() - t0) / 1e6
        frameMs = ms; passesNow = n; busyMs += ms
        work += n.toDouble() * w * h * LOOP
        frames++
        if (System.nanoTime() < calibUntil) {
            passes = (passes * 0.6 + passes * targetMs / max(ms, 0.5) * 0.4).coerceIn(1.0, 128.0)
        } else if (ms > 250.0) {
            passes = max(1.0, passes * 0.7)
        }
        val d = duty
        if (d < 100) { try { Thread.sleep((ms * (100 - d) / d).toLong().coerceAtMost(500)) } catch (_: InterruptedException) {} }
    }
}
