plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val withNative = project.hasProperty("withNative")
val xtreme = project.hasProperty("xtreme")
android {
    namespace = "com.edi.stress"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.edi.stress"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
        if (withNative) {
            ndk { abiFilters += "arm64-v8a" }
            if (xtreme) {
                externalNativeBuild {
                    cmake { arguments("-DXTREME=ON") }
                }
            }
        }
    }
    if (withNative) {
        val ndkEnv = System.getenv("ANDROID_NDK_HOME") ?: System.getenv("ANDROID_NDK_ROOT")
        if (ndkEnv != null) ndkPath = ndkEnv
        externalNativeBuild {
            cmake { path = file("src/main/cpp/CMakeLists.txt") }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
