#!/bin/bash
# 1) NEON + AES + dot-product   2) faqat NEON   3) faqat Kotlin
if gradle assembleDebug -PwithNative=true -Pxtreme=true --no-daemon; then
  echo "=== YIG'ILDI: NEON + AES + DOT (eng kuchli) ==="
elif gradle clean assembleDebug -PwithNative=true --no-daemon; then
  echo "=== YIG'ILDI: faqat NEON ==="
else
  echo "=== faqat Kotlin bilan yig'ilmoqda ==="
  gradle clean assembleDebug --no-daemon
fi
